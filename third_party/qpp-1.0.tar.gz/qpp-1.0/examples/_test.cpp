// Used for testing, do not use it as an example
#include <iostream>

#include "qpp.h"

int main() {}
