var annotated_dup =
[
    [ "qpp", "namespaceqpp.html", "namespaceqpp" ]
];