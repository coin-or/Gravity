var classqpp_1_1exception_1_1_not_qubit_matrix =
[
    [ "type_description", "classqpp_1_1exception_1_1_not_qubit_matrix.html#a02788b425554a6e2513e386be9f65a32", null ]
];