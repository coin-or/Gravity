var structqpp_1_1experimental_1_1_bit__circuit_1_1_gate__count =
[
    [ "CNOT", "structqpp_1_1experimental_1_1_bit__circuit_1_1_gate__count.html#a9e2043ece9e57eee77a7dfaf111dd60f", null ],
    [ "FRED", "structqpp_1_1experimental_1_1_bit__circuit_1_1_gate__count.html#a0a8bd23cfe3463283aa22f7710b9fb82", null ],
    [ "NOT", "structqpp_1_1experimental_1_1_bit__circuit_1_1_gate__count.html#a5b3a0d3ad47879936aa1f1702f8cb47a", null ],
    [ "SWAP", "structqpp_1_1experimental_1_1_bit__circuit_1_1_gate__count.html#a0fb6ae51bb0ae2e3869a0862788c9e57", null ],
    [ "TOF", "structqpp_1_1experimental_1_1_bit__circuit_1_1_gate__count.html#a0036b2bb4ecbe65711e012959f7a1a9a", null ],
    [ "X", "structqpp_1_1experimental_1_1_bit__circuit_1_1_gate__count.html#a4f538b5f91925435cfc1e8d69999a412", null ]
];