var classqpp_1_1exception_1_1_perm_mismatch_dims =
[
    [ "type_description", "classqpp_1_1exception_1_1_perm_mismatch_dims.html#afa6df21a1699c5b11a891df34252d5d7", null ]
];