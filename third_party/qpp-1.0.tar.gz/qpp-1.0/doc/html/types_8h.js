var types_8h =
[
    [ "bigint", "types_8h.html#ad199ade0836f0d8488e7f6c7c8aa1949", null ],
    [ "bra", "types_8h.html#a8886624a4a55a9b45c96a623a20bf163", null ],
    [ "cmat", "types_8h.html#ab0de67006716bdc8fae52c6a49259276", null ],
    [ "cplx", "types_8h.html#aad7ccc50a6b139279d7b56d07112b183", null ],
    [ "dmat", "types_8h.html#a923e2becc99eb818c04c71ae913902ff", null ],
    [ "dyn_col_vect", "types_8h.html#a07c62992d1a236f062887990eea26b15", null ],
    [ "dyn_mat", "types_8h.html#ac39e7c2b66f0209911cc3afc06223648", null ],
    [ "dyn_row_vect", "types_8h.html#ad94b7f2170b530b81ea9e1d167938589", null ],
    [ "idx", "types_8h.html#a1f5f7137e8551cf82db04d3b81cdd706", null ],
    [ "ket", "types_8h.html#a5d7185dfc7bee58c937abc243c3692ea", null ]
];