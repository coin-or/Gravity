var constants_8h =
[
    [ "omega", "constants_8h.html#a621afdaae12a94a5e10a874fc2073dc0", null ],
    [ "operator\"\" _i", "constants_8h.html#a93e5d55504a358ec5758ba472b99abcb", null ],
    [ "operator\"\" _i", "constants_8h.html#a12e22073e741a1057129fa01b4ec10a6", null ],
    [ "chop", "constants_8h.html#a3a6d2c509bdcf240869e1bebb3be4e94", null ],
    [ "ee", "constants_8h.html#aca5c7e10fa94db0755cb937250144630", null ],
    [ "eps", "constants_8h.html#a9a99ccccd473a9006dfaadb5761ac4f6", null ],
    [ "infty", "constants_8h.html#aecd9c0f42f21f1d3b29868b6a8cac4c7", null ],
    [ "maxn", "constants_8h.html#aea80be6c57ee43e43aa9629942cd3608", null ],
    [ "pi", "constants_8h.html#a73c04db6f636b236d64fddb069bef492", null ]
];