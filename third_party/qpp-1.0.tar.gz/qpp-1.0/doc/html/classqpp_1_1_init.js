var classqpp_1_1_init =
[
    [ "Init", "classqpp_1_1_init.html#a5650a0e31393cf13755262328f2122e9", null ],
    [ "~Init", "classqpp_1_1_init.html#af6c4566d220d568199e1ca9d954cb8da", null ],
    [ "internal::Singleton< const Init >", "classqpp_1_1_init.html#ac8d1cd0592921282440f9287abf4f22c", null ]
];