var classqpp_1_1exception_1_1_matrix_not_vector =
[
    [ "type_description", "classqpp_1_1exception_1_1_matrix_not_vector.html#ae11a6860f46424b8fccd0690581f204c", null ]
];