var classqpp_1_1exception_1_1_perm_invalid =
[
    [ "type_description", "classqpp_1_1exception_1_1_perm_invalid.html#a57da460973311589b1f8073c57f2d1f1", null ]
];