var classqpp_1_1exception_1_1_matrix_not_square_nor_vector =
[
    [ "type_description", "classqpp_1_1exception_1_1_matrix_not_square_nor_vector.html#a9b10cf365978e1a6a461f3b053cfd45b", null ]
];