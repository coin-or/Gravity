var classqpp_1_1exception_1_1_matrix_not_rvector =
[
    [ "type_description", "classqpp_1_1exception_1_1_matrix_not_rvector.html#a974a28a1df6f8c3d83fdf556c38a0948", null ]
];