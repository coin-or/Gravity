var files =
[
    [ "classes", "dir_b02e4219757ae4e3a0f1714873865bbf.html", "dir_b02e4219757ae4e3a0f1714873865bbf" ],
    [ "experimental", "dir_8c0381a6091af7a47ae909a45b674508.html", "dir_8c0381a6091af7a47ae909a45b674508" ],
    [ "internal", "dir_7374381ecdb819c64ee9b6ea2bd3370d.html", "dir_7374381ecdb819c64ee9b6ea2bd3370d" ],
    [ "MATLAB", "dir_26e95c14e39a3b2aa874b4ad85a981a5.html", "dir_26e95c14e39a3b2aa874b4ad85a981a5" ],
    [ "constants.h", "constants_8h.html", "constants_8h" ],
    [ "entanglement.h", "entanglement_8h.html", "entanglement_8h" ],
    [ "entropies.h", "entropies_8h.html", "entropies_8h" ],
    [ "functions.h", "functions_8h.html", "functions_8h" ],
    [ "input_output.h", "input__output_8h.html", "input__output_8h" ],
    [ "instruments.h", "instruments_8h.html", "instruments_8h" ],
    [ "number_theory.h", "number__theory_8h.html", "number__theory_8h" ],
    [ "operations.h", "operations_8h.html", "operations_8h" ],
    [ "qpp.h", "qpp_8h.html", "qpp_8h" ],
    [ "random.h", "random_8h.html", "random_8h" ],
    [ "statistics.h", "statistics_8h.html", "statistics_8h" ],
    [ "traits.h", "traits_8h.html", "traits_8h" ],
    [ "types.h", "types_8h.html", "types_8h" ]
];