var entropies_8h =
[
    [ "entropy", "entropies_8h.html#a922127fa0dd6659113c8277de8731c41", null ],
    [ "entropy", "entropies_8h.html#a11fd22e80ba664a4585ce87b45262efd", null ],
    [ "qmutualinfo", "entropies_8h.html#a336521e1a561be170d44dd5a1bc81c1d", null ],
    [ "qmutualinfo", "entropies_8h.html#a1dfb291551237e2a5b45e335141e759a", null ],
    [ "renyi", "entropies_8h.html#a991bc6df4280943452bfbedafa65b9f7", null ],
    [ "renyi", "entropies_8h.html#ae0268f55bb9b2fdd0495d8b67f74f6e3", null ],
    [ "tsallis", "entropies_8h.html#aeff1197fe1e27f2dc5caeb032d80f6b4", null ],
    [ "tsallis", "entropies_8h.html#a0439ba7f33753937fee671afe3250554", null ]
];