var structqpp_1_1make__void =
[
    [ "type", "structqpp_1_1make__void.html#a131e8cf5e1c59a5bed4a97dd31ce713c", null ]
];