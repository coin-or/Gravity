var classqpp_1_1exception_1_1_dims_mismatch_matrix =
[
    [ "type_description", "classqpp_1_1exception_1_1_dims_mismatch_matrix.html#a8805a0ce3d9bcb1513bd094bc2d5e52c", null ]
];