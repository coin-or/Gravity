var statistics_8h =
[
    [ "avg", "statistics_8h.html#a01ac36cfcd131c44a35faf86c5bf4ebd", null ],
    [ "cor", "statistics_8h.html#acc5cef3ac2601b63d4afef384fd7499b", null ],
    [ "cov", "statistics_8h.html#aaf2dcd205e0f0075b067ea46d3755982", null ],
    [ "marginalX", "statistics_8h.html#a6231fc8c64c2d14bb701eb783d9d1e3a", null ],
    [ "marginalY", "statistics_8h.html#a7a770cae0d7a05ca4590dec72390ebc7", null ],
    [ "sigma", "statistics_8h.html#a5dac002761cbcfb72cdb6a573e2689c3", null ],
    [ "uniform", "statistics_8h.html#abc09834bbfdd7aebe3cd95d01c99b869", null ],
    [ "var", "statistics_8h.html#a88a9f78049d7bf991a2d3c9bd81a05dd", null ]
];