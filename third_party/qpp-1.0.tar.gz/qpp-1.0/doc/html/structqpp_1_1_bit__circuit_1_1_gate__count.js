var structqpp_1_1_bit__circuit_1_1_gate__count =
[
    [ "CNOT", "structqpp_1_1_bit__circuit_1_1_gate__count.html#a1a017f85278ca096a17738a793c78142", null ],
    [ "FRED", "structqpp_1_1_bit__circuit_1_1_gate__count.html#af3452dfca7da1839964bbd2cff8f8400", null ],
    [ "NOT", "structqpp_1_1_bit__circuit_1_1_gate__count.html#a4f408d3e53ca6cd76bdd2cb0ede27c69", null ],
    [ "SWAP", "structqpp_1_1_bit__circuit_1_1_gate__count.html#a6ddf4da849e2edece92c5912082bb68a", null ],
    [ "TOF", "structqpp_1_1_bit__circuit_1_1_gate__count.html#a77b95805f5cae32633333c00f5e212ee", null ],
    [ "X", "structqpp_1_1_bit__circuit_1_1_gate__count.html#ad94c2f991b607593ac46d7cb3c8dbe69", null ]
];